﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Linq;

namespace Utility.UM
{
    
    public enum EnumUMType { time, weight, lenght, temperature, volume, speed, voltage, pressure, hardness, energy }
    public enum EnumUnitOfMeasure { K, C, F, mm, cm, m, km, ft, mi, gr, kg, lb, sec, min, hour, m_s, km_h, mp_h, V, mV, kV, J, Pa, MPa, psi, kpsi, kgfm2, ti2 }

    /// <summary>
    /// This class rappresent a Unit of Measure and the parameters to convert it into international standard (IS).
    /// Formula: [Standard UM] = [value] * [Coefficient] + [Constant]
    /// </summary>
    public class UMInfo
    {
        public bool Standard { get; set; } //Is international standard UM
        public EnumUMType Type { get; set; }
        public EnumUnitOfMeasure UM { get; set;}
        public string Description { get; set;}
        public double Coefficient { get; set; } //coeficient to multiply in order to convert into International Standard UM equivalent 
        public double Constant { get; set; } //constant to add for the conversion

        public UMInfo(bool bStandard, EnumUMType oType, EnumUnitOfMeasure oUM, string sDescription, double fCoefficient, double fConstant = 0)
        {
            Standard = bStandard;
            Type = oType;
            UM = oUM;
            Description = sDescription;
            Coefficient = fCoefficient;
            Constant = fConstant;
        }
    }

    /// <summary>
    /// This class is dedicated to conver Units of Measures
    /// </summary>
    public class UMConversion
    {
        public List<UMInfo> UMInfos = new List<UMInfo>(); //List of all units

        public UMConversion()
        {
            Inizialize();
        }

        private void Inizialize()
        {
            //Space
            UMInfos.Add(new UMInfo(true, EnumUMType.lenght, EnumUnitOfMeasure.m, "meter", 1));
            UMInfos.Add(new UMInfo(false, EnumUMType.lenght, EnumUnitOfMeasure.cm, "millimeter", 0.001));
            UMInfos.Add(new UMInfo(false, EnumUMType.lenght, EnumUnitOfMeasure.mm, "centimeter", 0.01));
            UMInfos.Add(new UMInfo(false, EnumUMType.lenght, EnumUnitOfMeasure.mi, "mile", 1609.347));
            UMInfos.Add(new UMInfo(false, EnumUMType.lenght, EnumUnitOfMeasure.ft, "feet", 0.3048)); //3.2808

            //Weight
            UMInfos.Add(new UMInfo(true, EnumUMType.weight, EnumUnitOfMeasure.kg, "kg", 1));
            UMInfos.Add(new UMInfo(false, EnumUMType.weight, EnumUnitOfMeasure.gr, "gr", 0.001));
            UMInfos.Add(new UMInfo(false, EnumUMType.weight, EnumUnitOfMeasure.lb, "pound", 0.45359));

            //Temperature
            UMInfos.Add(new UMInfo(true, EnumUMType.temperature, EnumUnitOfMeasure.K, "Kelvin", 1));
            UMInfos.Add(new UMInfo(false, EnumUMType.temperature, EnumUnitOfMeasure.C, "Celsius", 1, 273.15)); //K = °C + 273,15
            UMInfos.Add(new UMInfo(false, EnumUMType.temperature, EnumUnitOfMeasure.F, "Fahrenheit", 0.5555, 255.3722)); //K = (°F + 459,67) / 1,8 => (°F / 1,8) + (459,67 / 1,8)  => (°F * 0.555) + 255.372

            //Time
            UMInfos.Add(new UMInfo(true, EnumUMType.time, EnumUnitOfMeasure.sec, "second", 1)); 
            UMInfos.Add(new UMInfo(false, EnumUMType.time, EnumUnitOfMeasure.min, "minute", 60)); 
            UMInfos.Add(new UMInfo(false, EnumUMType.time, EnumUnitOfMeasure.hour, "hour", 3600)); 

            //Speed
            UMInfos.Add(new UMInfo(true, EnumUMType.time, EnumUnitOfMeasure.m_s, "m/sec", 1));
            UMInfos.Add(new UMInfo(false, EnumUMType.time, EnumUnitOfMeasure.km_h, "km/h (kmph)", 3.6));
            UMInfos.Add(new UMInfo(false, EnumUMType.time, EnumUnitOfMeasure.mp_h, "mi/h (mph)", 5.7924));

            //Voltage
            UMInfos.Add(new UMInfo(true, EnumUMType.voltage, EnumUnitOfMeasure.V, "Volt", 1));
            UMInfos.Add(new UMInfo(false, EnumUMType.voltage, EnumUnitOfMeasure.mV, "mVolt", 0.001));

            UMInfos.Add(new UMInfo(true, EnumUMType.voltage, EnumUnitOfMeasure.V, "Volt", 1));
            UMInfos.Add(new UMInfo(false, EnumUMType.voltage, EnumUnitOfMeasure.kV, "kVolt", 1000));


            //Energy
            UMInfos.Add(new UMInfo(true, EnumUMType.voltage, EnumUnitOfMeasure.J, "Joule", 1));

            //Pressure
            UMInfos.Add(new UMInfo(true, EnumUMType.pressure, EnumUnitOfMeasure.Pa, "Pa", 1));
            UMInfos.Add(new UMInfo(false, EnumUMType.pressure, EnumUnitOfMeasure.MPa, "MPa", 1000));

            UMInfos.Add(new UMInfo(false, EnumUMType.pressure, EnumUnitOfMeasure.psi, "psi (lb/in²)", 6894.757));
            UMInfos.Add(new UMInfo(false, EnumUMType.pressure, EnumUnitOfMeasure.kpsi, "kpsi", 6.894757));
            //Hardness

            //Proportionality

        }

        /// <summary>
        /// Convert a value into the equivalent value in IS
        /// </summary>
        /// <param name="value"></param>
        /// <param name="um"></param>
        /// <returns></returns>
        public object Convert(double value, EnumUnitOfMeasure um)
        {
            UMInfo umsource = UMInfos.FirstOrDefault( i => i.UM ==  um );
            if (umsource == null) return null;
            return value * umsource.Coefficient + umsource.Constant;
        }

        /// <summary>
        /// Convert a value into the equivalent value in IS
        /// </summary>
        /// <param name="value"></param>
        /// <param name="um"></param>
        /// <returns></returns>
        public object Convert(double value, UMInfo um)
        {
            return Convert(value, um.UM);
        }

        /// <summary>
        /// Convert a value from Unit Of Measure to another Unit Of Measure
        /// </summary>
        /// <param name="value"></param>
        /// <param name="umFrom"></param>
        /// <param name="umTo"></param>
        /// <returns></returns>
        public object Convert(double value, EnumUnitOfMeasure umFrom, EnumUnitOfMeasure umTo)
        {
            UMInfo umsource = UMInfos.FirstOrDefault(i => i.UM == umFrom);
            UMInfo umtarget = UMInfos.FirstOrDefault(i => i.UM == umTo);

            if ((umsource == null) || (umtarget == null)) return null;
            if (umsource.Type != umtarget.Type) return null; //tipi di unità incompatibili

            double std1 = value * umsource.Coefficient + umsource.Constant;
            return (std1 - umtarget.Constant) / umtarget.Coefficient;
        }

        /// <summary>
        /// Convert a value from Unit Of Measure to another Unit Of Measure
        /// </summary>
        /// <param name="value"></param>
        /// <param name="umFrom"></param>
        /// <param name="umTo"></param>
        /// <returns></returns>
        public object Convert(double value, UMInfo umFrom, UMInfo umTo)
        {
            return Convert(value, umFrom.UM, umTo.UM);
        }

        /// <summary>
        /// Return the equivalent value into the International Standard Unit Of Measure 
        /// </summary>
        /// <param name="um"></param>
        /// <returns></returns>
        public UMInfo GetStandard(EnumUnitOfMeasure um)
        {
            UMInfo umsource = UMInfos.FirstOrDefault(i => i.UM == um);
            return UMInfos.FirstOrDefault(i => i.Type == umsource.Type && i.Standard == true);
        }

        /// <summary>
        /// Convert a Numerical string rappresentation into its equivalent in Operating System format settings.
        /// Replace . with , or viceversa.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public string GetOSFloat(string value)
        {
            string sepOK = Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator;
            string sep = (sepOK == ".") ? "," : ".";
            return value.Replace(sep, sepOK);            
        }
    }
}
