﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Utility.UM;

namespace UMConversion
{
    public partial class Form1 : Form
    {
        Utility.UM.UMConversion oUM = new Utility.UM.UMConversion();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (EnumUMType item in Enum.GetValues(typeof(EnumUMType)))
            {
                cmbType.Items.Add(item.ToString());
            }
            cmbType.SelectedItem = EnumUMType.temperature.ToString();            
        }

        private void RefreshCombo()
        {

            ClearAll();
            EnumUMType type = (EnumUMType)Enum.Parse(typeof(EnumUMType), cmbType.Text);
            List<UMInfo> list = oUM.UMInfos.Where(i => i.Type == type).OrderBy(i => i.Description).ToList();

            foreach (UMInfo item in list)
            {
                cmbFrom.Items.Add(item.Description);
                cmbTo.Items.Add(item.Description);
            }
            
        }

        private void ClearAll()
        {
            cmbFrom.Items.Clear();
            cmbTo.Items.Clear();
            cmbFrom.SelectedIndex = -1;
            cmbTo.SelectedIndex = -1;
            cmbFrom.Text = "";
            cmbTo.Text = "";
            txtValue.Text = "";
            lblResult.Text = "...";
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            if (cmbFrom.SelectedItem == null) 
            {
                MessageBox.Show("No Unit selected!");
                return; 
            }
            if (cmbFrom.SelectedItem == null)
            {
                MessageBox.Show("No Unit selected!");
                return;
            }

            UMInfo from = oUM.UMInfos.FirstOrDefault(i => i.Description == cmbFrom.Text);
            UMInfo to = oUM.UMInfos.FirstOrDefault(i => i.Description == cmbTo.Text);

            if (txtValue.Text == "")
            {
                lblResult.Text = "Error!";
                return;
            }

            double val = double.Parse(txtValue.Text);
            object res = oUM.Convert(val, from.UM, to.UM);

            lblResult.Text = "Error!";
            if (res == null) return;
            lblResult.Text = string.Format("{0:0.####}", res);

        }

        private void cmbType_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefreshCombo();
        }
    }
}
