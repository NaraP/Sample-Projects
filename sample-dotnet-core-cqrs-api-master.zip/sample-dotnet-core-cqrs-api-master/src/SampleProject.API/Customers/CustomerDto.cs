﻿using System;

namespace SampleProject.API.Customers
{
    public class CustomerDto
    {
        public Guid Id { get; set; }
    }
}