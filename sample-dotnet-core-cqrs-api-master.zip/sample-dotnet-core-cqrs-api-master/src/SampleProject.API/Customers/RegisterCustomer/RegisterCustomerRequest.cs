﻿namespace SampleProject.API.Customers.RegisterCustomer
{
    public class RegisterCustomerRequest
    {
        public string Email { get; set; }

        public string Name { get; set; }
    }
}