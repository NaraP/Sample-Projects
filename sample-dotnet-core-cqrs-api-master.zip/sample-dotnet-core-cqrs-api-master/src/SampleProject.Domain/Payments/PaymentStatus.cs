﻿namespace SampleProject.Domain.Payments
{
    public enum PaymentStatus
    {
        ToPay = 0,
        Payed = 1,
        Overdue = 2
    }
}