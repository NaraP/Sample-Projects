﻿namespace SampleProject.Infrastructure
{
    internal class SchemaNames
    {
        internal const string Orders = "orders";
        internal const string Application = "app";
        internal const string Payments = "payments";
    }
}