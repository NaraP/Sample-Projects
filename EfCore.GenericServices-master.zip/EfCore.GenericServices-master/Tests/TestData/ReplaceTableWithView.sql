﻿CREATE VIEW ChildrenView
AS 
SELECT
    "ChildId",
    "MyString"
FROM
    WritableChildren;
GO