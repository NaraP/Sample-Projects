﻿namespace Npgsql.BulkCopy.Enums
{
    public enum PgVersions
    {
        PG8x = 8,
        PQ9x = 9
    }
}
