﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Npgsql.BulkCopy
{
    public static class BulkCopySettings
    {
        public const string CONFIG_FILE = "BulkCopyConfig.xml";

    }
}
