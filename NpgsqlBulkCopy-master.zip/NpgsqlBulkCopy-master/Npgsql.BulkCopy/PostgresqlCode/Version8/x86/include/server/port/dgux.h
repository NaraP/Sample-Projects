/* $PostgreSQL: pgsql/src/include/port/dgux.h,v 1.11 2007/04/06 05:36:51 tgl Exp $ */

/* nothing needed */
