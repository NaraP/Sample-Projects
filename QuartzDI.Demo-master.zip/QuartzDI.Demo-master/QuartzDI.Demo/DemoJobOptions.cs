﻿namespace QuartzDI.Demo
{
    public class DemoJobOptions
    {
        public string Url { get; set; }
    }
}
