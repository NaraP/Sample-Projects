The source code is currently hosted under a private GitHub repository.
The source code will be made public in case the company cease activity.
