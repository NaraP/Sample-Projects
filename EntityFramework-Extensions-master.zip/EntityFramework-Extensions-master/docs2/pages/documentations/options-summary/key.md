# Key

| Name                               | Description                                                           |
|:-----------------------------------|:----------------------------------------------------------------------|
|[AllowDuplicateKeys](../options/allow-duplicate-keys.md)  | Gets or sets if a duplicate key is possible in the source. |
|[AllowUpdatePrimaryKeys](../options/allow-update-primary-keys.md)  | Gets or sets if the key must also be included in columns to `UPDATE`. |
