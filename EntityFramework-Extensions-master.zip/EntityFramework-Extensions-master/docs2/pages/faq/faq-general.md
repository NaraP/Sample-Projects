# FAQ - General

## Which Payment method do you support?
We support the following payment methods:

- PayPal
- Check
- Bank Transfer

## Can I purchase this product from a Reseller?
Yes, just let him know how to contact us.

## What's your average SLA response and resolution time?
We try to provide an outstanding support service.

We normally answer very fast, often within one hour.

Most fixes are resolved within one business day.
