# FAQ

- [General](faq-general)
- [Installation](faq-installation)
- [Issue Tracker](issue-tracker)
- [License](faq-license)