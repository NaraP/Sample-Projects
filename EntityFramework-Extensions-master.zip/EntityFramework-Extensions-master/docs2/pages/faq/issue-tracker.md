# Issue Tracker

## Where is your Issue Tracker?

While we prefer to be contacted directly: info@zzzprojects.com

We understand some people prefer to have an online issue tracker to follow and comment their issues.

You can create an issue here:

- [Issue Tracker](https://github.com/zzzprojects/EntityFramework-Extensions/issues)
