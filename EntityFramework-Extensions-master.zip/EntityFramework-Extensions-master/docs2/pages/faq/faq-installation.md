# FAQ - Installation

## How to install your product?
It is simple, you download it from NuGet and add it to your project.

More Info: [Tutorials - Installing](installing)

## I have installed your product, but I don't see your extensions method
- Make sure to install it in the right project
- Make sure your project support .NET40 or better
