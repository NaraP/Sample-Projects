# Trial

Oops! Your trial has expired.

### How can I extend my trial?
You can extend your trial for several months by downloading the latest version at the beginning of every month.

<a class="btn btn-lg btn-z" role="button" href="/download" onclick="ga('send', 'event', { eventAction: 'download'});">
	<i class="fa fa-cloud-download" aria-hidden="true"></i>
	Download
	<i class="fa fa-angle-right"></i>
</a>

### Where is the free version?
There is no free version. All free features has been moved to a different library: <a href="http://entityframework-plus.net/" target="_blank">Entity Framework Plus</a>

### How can I purchase a license?
A perpetual license can be purchased from here: <a href="http://entityframework-extensions.net/pricing">Buy</a>
