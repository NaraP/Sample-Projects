﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreWebAPINLog.NLogger;
using Microsoft.AspNetCore.Mvc;

namespace CoreWebAPINLog.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private INLogger logger;
        public ValuesController(INLogger logger)
        {
            this.logger = logger;
        }

        // GET api/values  
        [HttpGet]
        public IEnumerable<string> Get()
        {
            logger.Information("Information is logged");
            logger.Warning("Warning is logged");
            logger.Debug("Debug log is logged");
            logger.Error("Error is logged");

            return new string[] { "value1", "value2" };
        }

        // GET api/values/5  
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values  
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5  
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5  
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    
}
}
