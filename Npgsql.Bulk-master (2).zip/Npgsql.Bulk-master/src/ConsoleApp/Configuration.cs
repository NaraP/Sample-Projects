﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp
{
    public static class Configuration
    {
        public const string ConnectionString =
            "User ID=abbadmin@abbrcsdatabse;Password=relcare123#;Host=abbrcsdatabse.postgres.database.azure.com;Port=5432;Database=abbrcdev;Pooling=true;";
    }
}
