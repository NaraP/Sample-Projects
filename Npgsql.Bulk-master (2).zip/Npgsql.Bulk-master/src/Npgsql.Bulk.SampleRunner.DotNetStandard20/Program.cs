﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.ChangeTracking.Internal;
using Microsoft.EntityFrameworkCore.ValueGeneration;
using Npgsql.Bulk.DAL;
using Npgsql.Bulk.SampleRunner.DotNetStandard20.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Transactions;

namespace Npgsql.Bulk.SampleRunner.DotNetStandard20
{
    class Program
    {
        static void Main(string[] args)
        {
            var streets = new[] { "First", "Second", "Third" };
            var codes = new[] { "001001", "002002", "003003", "004004" };
            var extraNumbers = new int?[] { null, 1, 2, 3, 5, 8, 13, 21, 34 };

            var optionsBuilder = new DbContextOptionsBuilder<BulkContext>();
            optionsBuilder.UseNpgsql(Configuration.ConnectionString);

            var context = new BulkContext(optionsBuilder.Options);
           context.Database.ExecuteSqlCommand("TRUNCATE rcs_app.article CASCADE");

            var data = Enumerable.Range(0, 2000)
                .Select((x, i) => new Article()
                {
                   ArticleId =i+1,
                    ArticleName = streets[i % streets.Length],
                    ArticleDesc = "test"+i,
                    DateAdded=DateTime.UtcNow
                }).ToList();

            var uploader = new NpgsqlBulkUploader(context);

            context.Attach(data[0]);

            var sw = Stopwatch.StartNew();
            uploader.Insert(data);
            sw.Stop();
            Console.WriteLine($"Dynamic solution inserted {data.Count} records for {sw.Elapsed }");
           // Trace.Assert(context.Addresses.Count() == data.Count);

            context.Database.ExecuteSqlCommand("TRUNCATE rcs_app.article CASCADE");

            //TestViaInterfaceCase(data, context);

            data.ForEach(x => x.ArticleId += 1);

            sw = Stopwatch.StartNew();
            uploader.Update(data);
            sw.Stop();
            Console.WriteLine($"Dynamic solution updated {data.Count} records for {sw.Elapsed }");

            context.Database.ExecuteSqlCommand("TRUNCATE rcs_app.article CASCADE");
            sw = Stopwatch.StartNew();
            uploader.Import(data);
            sw.Stop();
            Console.WriteLine($"Dynamic solution imported {data.Count} records for {sw.Elapsed }");

            // With transaction
            context.Database.ExecuteSqlCommand("TRUNCATE rcs_app.article CASCADE");

            using (var transaction = new TransactionScope())
            {
                uploader.Insert(data);
            }
            //Trace.Assert(context.Addresses.Count() == 0);

            sw = Stopwatch.StartNew();
            uploader.Update(data);
            sw.Stop();
            Console.WriteLine($"Dynamic solution updated {data.Count} records for {sw.Elapsed } (after transaction scope)");

            TestAsync(context, uploader, data).Wait();

            Console.ReadLine();
        }

        static async Task TestAsync(BulkContext context, NpgsqlBulkUploader uploader, List<Article> data)
        {
            Console.WriteLine("");
            Console.WriteLine("ASYNC version...");
            Console.WriteLine("");

            var sw = Stopwatch.StartNew();
            await uploader.InsertAsync(data);
            sw.Stop();
            Console.WriteLine($"Dynamic solution inserted {data.Count} records for {sw.Elapsed }");
          //  Trace.Assert(context.Addresses.Count() == data.Count);

            data.ForEach(x => x.ArticleId += 1);

            sw = Stopwatch.StartNew();
            await uploader.UpdateAsync(data);
            sw.Stop();
            Console.WriteLine($"Dynamic solution updated {data.Count} records for {sw.Elapsed }");

            context.Database.ExecuteSqlCommand("TRUNCATE rcs_app.article CASCADE");
            sw = Stopwatch.StartNew();
            await uploader.ImportAsync(data);
            sw.Stop();
            Console.WriteLine($"Dynamic solution imported {data.Count} records for {sw.Elapsed }");

            // With transaction
            context.Database.ExecuteSqlCommand("TRUNCATE rcs_app.article CASCADE");

            using (var transaction = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                await uploader.InsertAsync(data);
            }
           // Trace.Assert(context.Addresses.Count() == 0);

            sw = Stopwatch.StartNew();
            await uploader.UpdateAsync(data);
            sw.Stop();
            Console.WriteLine($"Dynamic solution updated {data.Count} records for {sw.Elapsed } (after transaction scope)");
        }

        static void TestViaInterfaceCase<T>(IEnumerable<T> data, DbContext context) where T : IHasId
        {
            var uploader = new NpgsqlBulkUploader(context);

            var properties = data
                .First()
                .GetType()
                .GetProperties()
                .Where(x=>x.GetCustomAttribute<ColumnAttribute>() != null)
                .ToArray();

            uploader.Insert(data, InsertConflictAction.UpdateProperty<T>(x => x.AddressId, properties));
        }
    }
}
