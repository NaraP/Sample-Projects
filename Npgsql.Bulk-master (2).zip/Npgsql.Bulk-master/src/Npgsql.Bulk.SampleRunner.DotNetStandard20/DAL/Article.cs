﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Npgsql.Bulk.SampleRunner.DotNetStandard20.DAL
{
    public partial class Article
    {
        public int ArticleId { get; set; }
        public string ArticleName { get; set; }
        public string ArticleDesc { get; set; }
        public DateTime? DateAdded { get; set; }
    }
}
