﻿using JetBrains.Annotations;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.ValueGeneration;
using System;
using Npgsql.Bulk.SampleRunner.DotNetStandard20.DAL;

namespace Npgsql.Bulk.DAL
{
    public class BulkContext : DbContext
    {
        public BulkContext()
        {
        }

        public BulkContext(DbContextOptions<BulkContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Area> Area { get; set; }
        public virtual DbSet<Article> Article { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.ForNpgsqlHasEnum("rcs_app", "change_status", new[] { "I", "D", "U" })
                .ForNpgsqlHasEnum("rcs_app", "comment_type", new[] { "C", "V" })
                .HasPostgresExtension("pg_buffercache")
                .HasPostgresExtension("pg_stat_statements")
                .HasPostgresExtension("uuid-ossp")
                .HasAnnotation("ProductVersion", "2.2.6-servicing-10079");
            modelBuilder.Entity<Area>(entity =>
            {
                entity.ToTable("area", "rcs_app");

                entity.Property(e => e.AreaId)
                    .HasColumnName("area_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.AreaName)
                            .IsRequired()
                            .HasColumnName("area_name")
                            .HasMaxLength(25);

                entity.Property(e => e.CreateTs).HasColumnName("create_ts");

                entity.Property(e => e.CreateUser).HasColumnName("create_user");

                entity.Property(e => e.IsActive)
                            .IsRequired()
                            .HasColumnName("is_active")
                            .HasDefaultValueSql("true");

                entity.Property(e => e.UpdateTs).HasColumnName("update_ts");

                entity.Property(e => e.UpdateUser).HasColumnName("update_user");
            });
            modelBuilder.Entity<Article>(entity =>
            {
                entity.ToTable("article", "rcs_app");

                entity.Property(e => e.ArticleId)
                    .HasColumnName("article_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.ArticleDesc)
                    .IsRequired()
                    .HasColumnName("article_desc");

                entity.Property(e => e.ArticleName)
                    .HasColumnName("article_name")
                    .HasMaxLength(20);

                entity.Property(e => e.DateAdded)
                    .HasColumnName("date_added")
                    .HasColumnType("date");
            });
        }
    }

public class ValueGen : ValueGenerator
    {
        public override bool GeneratesTemporaryValues => false;

        protected override object NextValue(EntityEntry entry)
        {
            return DateTime.Now;
        }
    }
}
