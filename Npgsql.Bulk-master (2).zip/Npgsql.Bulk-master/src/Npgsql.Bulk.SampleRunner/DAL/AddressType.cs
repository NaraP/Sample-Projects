﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Npgsql.Bulk.DAL
{
    public enum AddressType
    {

        Type1 = 1,

        Type2 = 2

    }
}
