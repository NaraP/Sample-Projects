﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyCompany("Twilio SendGrid")]
[assembly: AssemblyProduct("Example")]
[assembly: AssemblyTrademark("Twilio SendGrid")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("4bd07a97-8ad2-4134-848e-6a74eb992050")]
