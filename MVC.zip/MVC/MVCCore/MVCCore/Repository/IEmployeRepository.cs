﻿using MVCCore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCCore.Repository
{
  public  interface IEmployeRepository
    {
        List<Employeedetail> GetAllEmployees();
        int AddEmployee(Employeedetail employee);
        int UpdateEmployee(Employeedetail employee);
        Employeedetail GetEmployeeData(int id);
        int DeleteEmployee(int id);
        //List<Cities> GetCities();
    }
}
