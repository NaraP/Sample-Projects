﻿using Microsoft.EntityFrameworkCore;
using MVCCore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCCore.Repository
{
    public class EmployeRepository : IEmployeRepository
    {
        private readonly SampleDbContext _sampleDbContext;

        public EmployeRepository(SampleDbContext employeRepository)
        {
            _sampleDbContext = employeRepository;
        }

        public List<Employeedetail> GetAllEmployees()
        {
            try
            {
                return _sampleDbContext.Employeedetail.ToList();
            }
            catch
            {
                throw;
            }
        }

        //To Add new employee record   
        public int AddEmployee(Employeedetail employee)
        {
            try
            {
                _sampleDbContext.Employeedetail.Add(employee);
                _sampleDbContext.SaveChanges();
                return 1;
            }
            catch
            {
                throw;
            }
        }

        //To Update the records of a particluar employee  
        public int UpdateEmployee(Employeedetail employee)
        {
            try
            {
                _sampleDbContext.Entry(employee).State = EntityState.Modified;
                _sampleDbContext.SaveChanges();

                return 1;
            }
            catch
            {
                throw;
            }
        }

        //Get the details of a particular employee  
        public Employeedetail GetEmployeeData(int id)
        {
            try
            {
                Employeedetail employee = _sampleDbContext.Employeedetail.Find(id);
                return employee;
            }
            catch
            {
                throw;
            }
        }

        //To Delete the record of a particular employee  
        public int DeleteEmployee(int id)
        {
            try
            {
                Employeedetail emp = _sampleDbContext.Employeedetail.Find(id);
                _sampleDbContext.Employeedetail.Remove(emp);
                _sampleDbContext.SaveChanges();
                return 1;
            }
            catch
            {
                throw;
            }
        }

        //To Get the list of Cities  
        //public List<Cities> GetCities()
        //{
        //    List<Cities> lstCity = new List<Cities>()
        //    {
        //        new Cities{Id=1,Name="New Delhi"},
        //        new Cities{Id=2,Name="New Delhi"},
        //        new Cities{Id=3,Name="Hyderabad"},
        //        new Cities{Id=4,Name="Chennai"},
        //        new Cities{Id=5,Name="Bengaluru"}
        //    };


        //    // lstCity = (from CityList in _sampleDbContext.Cities select CityList).ToList();

        //    return lstCity;
        //}
    }
}
