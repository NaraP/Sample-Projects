﻿using System;
using System.Collections.Generic;

namespace MVCCore.Models
{
    public partial class Employeedetail
    {
        public int Empid { get; set; }
        public string Empname { get; set; }
        public DateTime? Dateofbirth { get; set; }
        public string Emailid { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public string Pincode { get; set; }
    }
}
