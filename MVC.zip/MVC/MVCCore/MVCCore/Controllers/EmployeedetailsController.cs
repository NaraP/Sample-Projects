﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MVCCore.Models;

namespace MVCCore.Controllers
{

    public class EmployeedetailsController : Controller
    {
        private readonly SampleDbContext _context;

        private readonly ILogger<EmployeedetailsController> logger;
     
        public EmployeedetailsController(SampleDbContext context, ILogger<EmployeedetailsController> logger)
        {
            _context = context;
            this.logger = logger;
        }

        [HttpGet]
        public string Get()
        {
            string envVariable = String.Empty;

            try
            {
                using (logger.BeginScope($"API-GetName-Initiated {DateTime.UtcNow}"))
                {
                    logger.LogInformation("", "API-GetName-Getting all items");

                    envVariable = Environment.GetEnvironmentVariable("ElasticConfiguration");
                    logger.LogInformation($"API-GetName-Completed {DateTime.UtcNow}");
                }
            }
            catch (Exception ex)
            {
                logger.LogError
                   (ex,
                    $"API-GetName-Exception {DateTime.UtcNow}"
                  );
            }
            return envVariable;
        }


        // GET: Employeedetails
        public async Task<IActionResult> Index()
        {
            var Employeedetail = new List<Employeedetail>();

            try
            {
                using (logger.BeginScope($"API-Index-Initiated {DateTime.UtcNow}"))
                {
                    logger.LogInformation("API-Index-Getting all employees data.");

                    Employeedetail = await _context.Employeedetail.ToListAsync();

                    logger.LogInformation($"API-Index-Completed {DateTime.UtcNow}");
                }
            }
            catch (Exception ex)
            {
                logger.LogError
                    (ex,
                     $"API-Index-Exception {DateTime.UtcNow}"
                   );
            }
            return View(Employeedetail);

        }

        // GET: Employeedetails/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            var employeedetail = default(Employeedetail);

            try
            {
                using (logger.BeginScope($"API-Details-Initiated {DateTime.UtcNow}"))
                {
                    logger.LogInformation("API-Details-Getting all deatisl.");

                    if (id == null)
                    {
                        return NotFound();
                    }

                    employeedetail = await _context.Employeedetail
                       .FirstOrDefaultAsync(m => m.Empid == id);

                    if (employeedetail == null)
                    {
                        return NotFound();
                    }

                    logger.LogInformation($"API-Details-Completed {DateTime.UtcNow}");
                }
            }
            catch (Exception ex)
            {
                logger.LogError
                    (ex,
                     $"API-Details-Exception {DateTime.UtcNow}"
                   );
            }

            return View(employeedetail);
        }

        // GET: Employeedetails/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Employeedetails/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Empid,Empname,Dateofbirth,Emailid,Gender,Address,Pincode")] Employeedetail employeedetail)
        {
            try
            {
                using (logger.BeginScope($"API-Create-Initiated {DateTime.UtcNow}"))
                {
                    logger.LogInformation("API-Create-Getting all employees data.");

                    var seq = Enumerable.Range(4, 1000);

                    if (ModelState.IsValid)
                    {
                        employeedetail.Empid = seq.First();
                        _context.Add(employeedetail);
                        await _context.SaveChangesAsync();
                        return RedirectToAction(nameof(Index));
                    }

                    logger.LogInformation($"API-Create-Completed {DateTime.UtcNow}");
                }
            }
            catch (Exception ex)
            {
                logger.LogError
                    (ex,
                     $"API-Create-Exception {DateTime.UtcNow}"
                   );
            }


            return View(employeedetail);
        }

        // GET: Employeedetails/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            var employeedetail = default(Employeedetail);
            try
            {
                using (logger.BeginScope($"API-Edit-Initiated {DateTime.UtcNow}"))
                {
                    logger.LogInformation("API-Edit-Getting all employees data.");

                    if (id == null)
                    {
                        return NotFound();
                    }

                     employeedetail = await _context.Employeedetail.FindAsync(id);
                    if (employeedetail == null)
                    {
                        return NotFound();
                    }
                    logger.LogInformation($"API-Edit-Completed {DateTime.UtcNow}");
                }
            }
            catch (Exception ex)
            {
                logger.LogError
                    (ex,
                     $"API-Edit-Exception {DateTime.UtcNow}"
                   );
            }




            return View(employeedetail);
        }

        // POST: Employeedetails/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Empid,Empname,Dateofbirth,Emailid,Gender,Address,Pincode")] Employeedetail employeedetail)
        {
            try
            {
                using (logger.BeginScope($"API-Edit-Initiated {DateTime.UtcNow}"))
                {
                    logger.LogInformation("API-Edit- all employees data.");

                    if (id != employeedetail.Empid)
                    {
                        return NotFound();
                    }

                    if (ModelState.IsValid)
                    {
                        try
                        {
                            _context.Update(employeedetail);
                            await _context.SaveChangesAsync();
                        }
                        catch (DbUpdateConcurrencyException)
                        {
                            if (!EmployeedetailExists(employeedetail.Empid))
                            {
                                return NotFound();
                            }
                            else
                            {
                                throw;
                            }
                        }
                        return RedirectToAction(nameof(Index));
                    }
                    logger.LogInformation($"API-Edit-Completed {DateTime.UtcNow}");
                }
            }
            catch (Exception ex)
            {
                logger.LogError
                    (ex,
                     $"API-Edit-Exception {DateTime.UtcNow}"
                   );
            }

            return View(employeedetail);
        }

        // GET: Employeedetails/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            var employeedetail = default(Employeedetail);

            try
            {
                using (logger.BeginScope($"API-Delete-Initiated {DateTime.UtcNow}"))
                {
                    logger.LogInformation("API-Delete- all employees data.");

                    if (id == null)
                    {
                        return NotFound();
                    }

                    employeedetail = await _context.Employeedetail
                       .FirstOrDefaultAsync(m => m.Empid == id);
                    if (employeedetail == null)
                    {
                        return NotFound();
                    }
                    logger.LogInformation($"API-Delete-Completed {DateTime.UtcNow}");
                }
            }
            catch (Exception ex)
            {
                logger.LogError
                    (ex,
                     $"API-Delete-Exception {DateTime.UtcNow}"
                   );
            }

            return View(employeedetail);
        }

        // POST: Employeedetails/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
           



            try
            {
                using (logger.BeginScope($"API-Delete-Initiated {DateTime.UtcNow}"))
                {
                    logger.LogInformation("API-Delete- all employees data.");

                    var employeedetail = await _context.Employeedetail.FindAsync(id);
                    _context.Employeedetail.Remove(employeedetail);
                    await _context.SaveChangesAsync();
                    logger.LogInformation($"API-Delete-Completed {DateTime.UtcNow}");
                }
            }
            catch (Exception ex)
            {
                logger.LogError
                    (ex,
                     $"API-Delete-Exception {DateTime.UtcNow}"
                   );
            }
            return RedirectToAction(nameof(Index));
        }

        private bool EmployeedetailExists(int id)
        {
            return _context.Employeedetail.Any(e => e.Empid == id);
        }
    }
}
