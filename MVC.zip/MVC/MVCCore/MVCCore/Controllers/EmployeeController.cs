﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MVCCore.Models;
using MVCCore.Repository;

namespace MVCCore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : Controller
    {
        public readonly IEmployeRepository _objemployee;

        public EmployeeController(IEmployeRepository objemployee)
        {
            _objemployee = objemployee;
        }

        [HttpGet]
        public IEnumerable<Employeedetail> Index()
        {
            return _objemployee.GetAllEmployees();
        }

        [HttpPost]
        public IActionResult Create([FromBody] Employeedetail employee)
        {
            var result= _objemployee.AddEmployee(employee);

            return View(result);
        }

        [HttpGet]
        public Employeedetail Details(int id)
        {
            return _objemployee.GetEmployeeData(id);
        }

        [HttpPut]
        public int Edit([FromBody] Employeedetail employee)
        {
            return _objemployee.UpdateEmployee(employee);
        }

        [HttpDelete]
        public int Delete(int id)
        {
            return _objemployee.DeleteEmployee(id);
        }

        //[HttpGet]
        //[Route("api/Employee/GetCityList")]
        //public IEnumerable<Cities> Details()
        //{
        //    return _objemployee.GetCities();
        //}
    }
}