﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MVCCore.Models;
using MVCCore.Repository;

namespace MVCCore.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public readonly IEmployeRepository _objemployee;

        public HomeController(ILogger<HomeController> logger, IEmployeRepository objemployee)
        {
            _logger = logger;
            _objemployee = objemployee;
        }

        [HttpGet]
        public List<Employeedetail> Index()
        {
            var Employeedetail = new List<Employeedetail>();

            try
            {
                using (_logger.BeginScope($"API-Index-Initiated {DateTime.UtcNow}"))
                {
                    _logger.LogInformation("API-Index-Getting all Downloaded Project Settings.");

                     Employeedetail = _objemployee.GetAllEmployees();

                    _logger.LogInformation($"API-Index-Completed {DateTime.UtcNow}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError
                    (ex,
                     $"API-Index-Exception {DateTime.UtcNow}"
                   );
            }
            return Employeedetail;

        }

        [HttpPost]
        public IActionResult Create([FromBody] Employeedetail employee)
        {
            var result = _objemployee.AddEmployee(employee);

            return View(result);
        }

        [HttpGet]
        public Employeedetail Details(int id)
        {
            return _objemployee.GetEmployeeData(id);
        }

        [HttpPut]
        public int Edit([FromBody] Employeedetail employee)
        {
            return _objemployee.UpdateEmployee(employee);
        }

        [HttpDelete]
        public int Delete(int id)
        {
            return _objemployee.DeleteEmployee(id);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
