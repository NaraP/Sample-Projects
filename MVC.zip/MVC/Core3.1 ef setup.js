﻿https://github.com/dotnet/core/issues/3240

//////dotnet tool uninstall - g dotnet - ef

///dotnet tool install - g dotnet - ef--version 3.1.1
//dotnet tool install --global dotnet-ef --version 3.0.0-preview8.19405.11

//PM > enable - migrations
//PM > add - migration initial
//PM > update - database 