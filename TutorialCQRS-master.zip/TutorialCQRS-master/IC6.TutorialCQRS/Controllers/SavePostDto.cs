﻿namespace IC6.TutorialCQRS.Controllers
{
    public class SavePostDto
    {
        public string Title { get; set; }
        public string Body { get; set; }
    }
}