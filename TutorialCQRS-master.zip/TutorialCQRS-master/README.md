# TutorialCQRS

Simple CQRS on ASP Net Core
